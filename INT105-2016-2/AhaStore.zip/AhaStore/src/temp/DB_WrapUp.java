package temp;

import dbConnection.MyConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DB_WrapUp {

    public static void main(String[] args) {
        try {
            Connection conn = MyConnection.getConnection();
            PreparedStatement pt = conn.prepareStatement("SELECT * from product WHERE product_id=?");
            System.out.println("");
            
            
            
            conn.close();
        } catch (SQLException ex) {

        }

    }

}
