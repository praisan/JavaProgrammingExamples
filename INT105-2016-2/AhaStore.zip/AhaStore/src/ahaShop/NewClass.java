/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ahaShop;

import ahaShop.model.Order;
import ahaShop.model.Order_item;
import java.util.ArrayList;

public class NewClass {
    public static void main(String[] args) {
        ArrayList<Order_item> items=new ArrayList();
        items=Order_item.getOrder_item(4);
        for(Order_item temp:items){
            System.out.println(temp);
        }
        System.out.println("--------------");
        
        Order orderObj= Order.getOrder(4);
        System.out.println(orderObj);
        orderObj.writeMe();
    }
    
}
