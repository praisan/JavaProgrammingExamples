package ahaShop.model;

import dbConnection.MyConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Order_item {
    private Product prod;
    private int quantity;
    
    public Order_item(){
        prod=new Product();
    }

    public Order_item(Product prod, int quantity) {
        this.prod = prod;
        this.quantity = quantity;
    }

    public Product getProd() {
        return prod;
    }

    public void setProd(Product prod) {
        this.prod = prod;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    
    public double getTotalPrice() {
        return quantity*prod.getPtoduct_price();
    }
    
    private static void orm(ResultSet rs,Order_item item) throws SQLException{
        Product.orm(rs, item.getProd());
        item.setQuantity(rs.getInt("quantity"));
    }
    public static ArrayList<Order_item> getOrder_item(int order_id){
        ArrayList<Order_item> items=new ArrayList();
        Connection conn=MyConnection.getConnection();
        String sql="SELECT product.product_id, product_name, product_price as price, quantity"+
                " FROM order_item JOIN product ON order_item.product_id=product.product_id"+
                " WHERE order_id=?";
        Order_item temp=null;
        try {
            PreparedStatement pst=conn.prepareStatement(sql);
            pst.setInt(1, order_id);
            ResultSet rs=pst.executeQuery();
            while(rs.next()){
                temp=new Order_item();
                orm(rs,temp);
                items.add(temp);
            }
            
        } catch (SQLException ex) {
            System.err.println(ex);
        }finally{
            try {
                conn.close();
            } catch (SQLException ex) {
                System.err.println(ex);
            }
        }
        
        return items;
    }
    public int writeMe(int order_id, Connection conn){
        int result=0;
        String sql="INSERT INTO order_item (?,?,?,?)";
        try {
            PreparedStatement pst=conn.prepareStatement(sql);
            pst.setInt(1, order_id);
            pst.setInt(2, this.prod.getProduct_id());
            pst.setInt(3, this.quantity);
            pst.setDouble(4, this.prod.getPtoduct_price());
            result=pst.executeUpdate();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return result;
    }
    public int writeMe(int order_id){
        int result=0;
        Connection conn=MyConnection.getConnection();
        String sql="INSERT INTO order_item (?,?,?,?)";
        try {
            PreparedStatement pst=conn.prepareStatement(sql);
            pst.setInt(1, order_id);
            pst.setInt(2, this.prod.getProduct_id());
            pst.setInt(3, this.quantity);
            pst.setDouble(4, this.prod.getPtoduct_price());
            result=pst.executeUpdate();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }finally{
            try {
                conn.close();
            } catch (SQLException ex) {
                System.err.println(ex);
            }
        }
        return result;
    } 
    
    @Override
    public String toString() {
        return String.format("%-50s quantity %5d total %5.2f",prod.getProduct_name(),quantity,getTotalPrice());
    }
    
}
