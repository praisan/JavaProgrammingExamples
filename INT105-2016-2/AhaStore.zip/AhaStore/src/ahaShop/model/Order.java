package ahaShop.model;

import dbConnection.MyConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Order {

    private int order_id;
    private Customer customer;
    private String status;
    private ArrayList<Order_item> items = new ArrayList();

    public static enum Status {
        CLOSED, PENDING_PAYMENT, COMPLETE,
        PROCESSING, PAYMENT_REVIEW, PENDING;
    }

    public Order() {
        customer=new Customer();
    }

    public Order(int bill_id, Customer customer, String status) {
        this.order_id = bill_id;
        this.status = status;
        this.customer = customer;
    }

    public Order(int bill_id, String status) {
        this(bill_id, new Customer(0, "-", "-"), status);
    }

    public Order(int bill_id, Customer customer, String status, ArrayList items) {
        this(bill_id, customer, status);
        this.items = items;
    }

    public static Order getOrder(int order_id) {
        Connection conn = MyConnection.getConnection();
        String sql = "SELECT * "
                + " FROM orders "
                + " WHERE order_id=?";
        Order orderObj = new Order();

        PreparedStatement pst;
        try {
            pst = conn.prepareStatement(sql);
            pst.setInt(1, order_id);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                orm(rs, orderObj);
            }
        } catch (SQLException ex) {
            System.out.println("!! : " + ex.getMessage());
        }finally{
            try {
                conn.close();
            } catch (SQLException ex) {
                System.err.println(ex);
            }
        }
        return orderObj;

    }

    public static void orm(ResultSet rs, Order order) throws SQLException {
        order.setOrder_id(rs.getInt("order_id"));
        order.setStatus(rs.getString("status"));
        order.setItems(Order_item.getOrder_item(rs.getInt("order_id")));
    }

    public void addItem(Product prod, int quantity) {
        items.add(new Order_item(prod, quantity));
    }

    public int getOrder_id() {
        return order_id;
    }

    public void setOrder_id(int order_id) {
        this.order_id = order_id;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public ArrayList<Order_item> getItems() {
        return items;
    }

    public void setItems(ArrayList<Order_item> items) {
        this.items = items;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status.name();
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public double getTotalPrice() {
        double total = 0;
        for (Order_item temp : items) {
            total += temp.getTotalPrice();
        }
        return total;
    }
    public int writeMe(){
        int result=0;
        Connection conn=MyConnection.getConnection();
        String sql="INSERT INTO orders VALUES(?,?)";
        try {
            PreparedStatement pst=conn.prepareStatement(sql);
            pst.setInt(1, this.order_id);
            pst.setString(2, this.status);
            result=pst.executeUpdate();
            for(Order_item temp:items){
                temp.writeMe(order_id, conn);
            }
        } catch (SQLException ex) {
            System.out.println("!!-Class Order- "+ex.getMessage());
        }finally{
            try {
                conn.close();
            } catch (SQLException ex) {
                System.out.println(ex);
            }
        }
        return result;
    }

    @Override
    public String toString() {
        String str = "Bill id: " + order_id + ", status=" + status + "\n";
        int count = 0;
        for (Order_item temp : items) {
            count++;
            str += count + ". " + temp.toString() + "\n";
        }
        str += "Total: " + String.format("%.2f", getTotalPrice());
        return str;
    }

}
