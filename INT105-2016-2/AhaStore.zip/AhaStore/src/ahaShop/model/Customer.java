package ahaShop.model;
public class Customer {
    private long cust_id;
    private String name,sname;

    public Customer(long cust_id, String name, String sname) {
        this.cust_id = cust_id;
        this.name = name;
        this.sname = sname;
    }

    Customer() {
        this(0,"-","-");
    }

    public long getCust_id() {
        return cust_id;
    }

    public void setCust_id(long cust_id) {
        this.cust_id = cust_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSname() {
        return sname;
    }

    public void setSname(String sname) {
        this.sname = sname;
    }

    @Override
    public String toString() {
        return "Customer{" + "cust_id=" + cust_id + ", name=" + name + ", sname=" + sname + '}';
    }
    
    
}
