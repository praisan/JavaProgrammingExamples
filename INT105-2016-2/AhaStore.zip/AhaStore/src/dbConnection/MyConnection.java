package dbConnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class MyConnection {
    private static String driver="org.apache.derby.jdbc.ClientDriver";
    private static String dbURL="jdbc:derby://localhost:1527/aha_shop";
    private static String username="app";
    private static String password="app";

    public static Connection getConnection() {
        Connection conn=null;
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            conn=DriverManager.getConnection(dbURL,username,password);
        } catch (ClassNotFoundException ex) {
            System.out.println("!! "+ex.getMessage());
        } catch (SQLException ex) {
            System.out.println("!!! "+ex.getMessage());
        }
        return conn;
    }

    public static String getDriver() {
        return driver;
    }

    public static void setDriver(String driver) {
        MyConnection.driver = driver;
    }

    public static String getDbURL() {
        return dbURL;
    }

    public static void setDbURL(String dbURL) {
        MyConnection.dbURL = dbURL;
    }

    public static String getUsername() {
        return username;
    }

    public static void setUsername(String username) {
        MyConnection.username = username;
    }

    public static String getPassword() {
        return password;
    }

    public static void setPassword(String password) {
        MyConnection.password = password;
    }
    
    
}
